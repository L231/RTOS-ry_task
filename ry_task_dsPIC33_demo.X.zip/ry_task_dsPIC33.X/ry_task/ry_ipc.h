#ifndef __RY_IPC_H__
	#define	__RY_IPC_H__

#include "ry_type.h"



















#endif
