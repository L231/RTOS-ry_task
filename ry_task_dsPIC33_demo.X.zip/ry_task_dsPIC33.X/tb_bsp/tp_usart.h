#ifndef __TP_USART_H__
    #define    __TP_USART_H__



#include <stdint.h>


extern void ry_printf(const char * fmt,...);
extern void tp_uart_send(uint8_t *p, uint16_t len);



#endif
