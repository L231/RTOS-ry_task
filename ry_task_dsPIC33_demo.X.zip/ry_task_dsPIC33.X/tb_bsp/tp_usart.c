

#include <stdarg.h>
#include <string.h>
#include <stdio.h>

#include "uart1.h"
#include "tp_usart.h"
#include "ry_lib.h"


void tp_uart_send(uint8_t *p, uint16_t len)
{
    while(len--)
    {
        UART1_Write(*p++);
    }
}

static char gTxbuf[128];
void ry_printf(const char * fmt,...)
{
	uint16_t len;
	va_list ap;
//	char *buf;
	
//    buf = (char *)ry_malloc(128);
	va_start(ap, fmt);
	len = vsprintf(gTxbuf, fmt, ap);
	va_end(ap);
	tp_uart_send((uint8_t *)gTxbuf, len);
//    ry_free(buf);
}

#include <p33EP256MC506.h>
int fputc(int ch, FILE *f)
{
		/* ����һ���ֽ����ݵ����� */
		UART1_Write((uint8_t) ch);
		
		/* �ȴ�������� */
		while(U1STAbits.UTXBF == 1);
	
		return (ch);
}



