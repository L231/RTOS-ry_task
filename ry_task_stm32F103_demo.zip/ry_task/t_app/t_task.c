
#include "t_task.h"
#include "ry_lib.h"
#include "tp_run.h"


static ry_task_t *task_uart_comm;
static ry_task_t *task_adc;
static ry_task_t *task_dac;
static ry_task_t *task_null;

static ry_task_t *task_sem_send;
static ry_task_t *task_sem_rec;
static ry_task_t *task_mutex_send;
static ry_task_t *task_mutex_rec;
static ry_task_t *task_event_send;
static ry_task_t *task_event_rec;

static ry_task_t *task_breathe_led;

static ry_msg_t *ipc_test;
static ry_semaphore_t ipc_sem;
static ry_mutex_t ipc_mutex;
static ry_event_t ipc_event;

static ry_timer_t timer_test;
static ry_timer_t timer_cnt;

//static ry_u8_t uart_comm_task_stack[512];
//static ry_u8_t adc_task_stack[512];
//static ry_u8_t dac_task_stack[512];
//static ry_u8_t null_task_stack[512];

//static ry_u8_t sem_send[512];
//static ry_u8_t sem_rec[512];
//static ry_u8_t mutex_send[512];
//static ry_u8_t mutex_rec[512];
//static ry_u8_t event_send[512];
//static ry_u8_t event_rec[512];

//static ry_u8_t breathe_led_stack[512];

//static ry_u8_t *msg_buf[RY_IPC_MSG_NUM];


static void task_uart_comm_exe(void *p);
static void task_adc_exe(void *p);
static void task_dac_exe(void *p);
static void task_null_exe(void *p);

static void task_sem_send_exe(void *p);
static void task_sem_rec_exe(void *p);
static void task_mutex_send_exe(void *p);
static void task_mutex_rec_exe(void *p);
static void task_event_send_exe(void *p);
static void task_event_rec_exe(void *p);

static void task_breathe_led_exe(void *p);


static void timer_exe(void *p);
static void timer_cnt_exe(void *p);


void F_ry_task(void)
{
	ry_init();
	ry_timer_reg(&timer_test,
	              timer_exe,
	              0,
	              10000,
	              RY_TIMER_CYCLE);
	ry_timer_reg(&timer_cnt,
	              timer_cnt_exe,
	              0,
	              5000,
	              RY_TIMER_CYCLE);
	
	ipc_test = ry_msg_create(RY_MSG_FIFO, 6);
//	ry_msg_reg(&ipc_test, RY_MSG_FIFO, RY_IPC_MSG_NUM, msg_buf);
	ry_semaphore_reg(&ipc_sem, RY_SEM_FIFO_NORMAL, 5);
	ry_mutex_reg(&ipc_mutex, RY_LOCK_FIFO_INHERIT);
	ry_event_reg(&ipc_event, RY_EVENT_FIFO);
	
	task_uart_comm = ry_task_create("uart_comm",
              task_uart_comm_exe,
              0,
              0,
              10,
              256);
	task_adc = ry_task_create("task_adc",
              task_adc_exe,
              0,
              2,
              5,
              256);
	task_dac = ry_task_create("task_dac",
              task_dac_exe,
              0,
              2,
              10,
              256);
	task_breathe_led = ry_task_create("breathe_led",
							task_breathe_led_exe,
							0,
							11,
							5,
							256);
	task_null = ry_task_create("task_null",
              task_null_exe,
              0,
              8,
              10,
              256);
	task_sem_send = ry_task_create("task_sem_send",
              task_sem_send_exe,
              0,
              3,
              5,
              256);
	task_sem_rec = ry_task_create("task_sem_rec",
              task_sem_rec_exe,
              0,
              3,
              5,
              256);
							
	task_mutex_send = ry_task_create("task_mutex_send",
              task_mutex_send_exe,
              0,
              4,
              5,
              256);
	task_mutex_rec = ry_task_create("task_mutex_rec",
              task_mutex_rec_exe,
              0,
              4,
              5,
              256);
							
	task_event_send = ry_task_create("task_event_send",
              task_event_send_exe,
              0,
              5,
              5,
              256);
	task_event_rec = ry_task_create("task_event_rec",
              task_event_rec_exe,
              0,
              5,
              5,
              256);
  ry_start();
	
	/* ��Զ�������е����� */
	NVIC_SystemReset();
}



static void task_uart_comm_exe(void *p)
{
	uint32_t cnt = 0;
	while(1)
	{
		cnt++;
		TP_Printf("\r\n(%d)uart_send_data\r\n", cnt);
		ry_task_delay(2000);
	}
}

static void task_adc_exe(void *p)
{
	uint32_t cnt = 0;
	ry_u8_t *buf;
	while(1)
	{
		cnt++;
		buf = ry_msg_rec(ipc_test, RY_RC, -1);
		if(buf == RY_NULL)
		{
			TP_Printf("\r\n�ʼ������쳣\r\n");
		}
		else
		{
			TP_Printf("msg:%s\r\n", (char *)buf);
		}
		buf = RY_NULL;
//		ry_task_delay(1000);
	}
}

static void task_dac_exe(void *p)
{
	char buf[] = "ry_task��1�ⱨ��[ ]";
	char msg = '0';
	while(1)
	{
		buf[sizeof(buf)-3] = msg++;
		if(msg == 0x7E)
			msg = '0';
		if(ry_msg_send(ipc_test, RY_MSG_SEND_NORMAL, (ry_u8_t *)buf) != RY_OK)
			TP_Printf("\r\n�ʼ������쳣\r\n");
		ry_task_delay(1000);
	}
}


	uint8_t *mp1, *mp2, *mp3, *mp4;
ry_mempool_t *TestMem;

static void task_null_exe(void *p)
{
	uint8_t *pbuf;
	uint32_t *cnt;
	cnt = (uint32_t *)ry_malloc(4);
	pbuf = (uint8_t *)ry_malloc(512);
//	ry_mempool_reg(&TestMem, buf, 128, 4);
	TestMem = ry_mempool_create(16, 4);
	mp1 = ry_mempool_malloc(TestMem, -1);
	mp3 = ry_mempool_malloc(TestMem, -1);
	while(1)
	{
//		ry_time_point_start();
		*cnt = 0;
		while((*cnt) < 0x2FFF)
		{
			pbuf[(*cnt) & 0x1FF] = (*cnt);
			(*cnt)++;
			mp1[*cnt & 0x3] = (*cnt);
			mp3[*cnt & 0x3] = (*cnt) + 3;
		}
//		ry_time_point_end();
//		TP_Printf("mp1:%#X\n", (uint32_t)mp1);
//		TP_Printf("mp3:%#X\n", (uint32_t)mp3);
	ry_mempool_free(mp1);
//		TP_Printf("mp1�ͷ��ڴ�\n");
	mp2 = ry_mempool_malloc(TestMem, -1);
//		TP_Printf("mp2:%#X\n", (uint32_t)mp2);
	mp4 = ry_mempool_malloc(TestMem, -1);
//		TP_Printf("mp4:%#X\n", (uint32_t)mp4);
	mp1 = ry_mempool_malloc(TestMem, -1);
//		TP_Printf("mp1�ٴ������ڴ棺%#X\n", (uint32_t)mp1);
		mp2[0] = 0xff;
		mp4[0] = 0xff;
		ry_task_delay(10);
	ry_mempool_free(mp1);
	ry_mempool_free(mp2);
	ry_mempool_free(mp3);
	ry_mempool_free(mp4);
	}
}

static void task_sem_send_exe(void *p)
{
	while(1)
	{
		ry_task_delay(1000);
		if(ry_sem_release(&ipc_sem) != RY_OK)
			TP_Printf("\r\nipc_sem�����쳣\r\n");
	}
}
static void task_sem_rec_exe(void *p)
{
	while(1)
	{
		if(ry_sem_rec(&ipc_sem, -1) != RY_OK)
			TP_Printf("\r\nipc_sem�����쳣\r\n");
		else
			TP_Printf("[sem]");
//		ry_task_delay(1000);
	}
}
static void task_mutex_send_exe(void *p)
{
	while(1)
	{
		if(ry_sem_rec(&ipc_mutex, -1) != RY_OK)
			TP_Printf("\r\nipc_mutex�����쳣\r\n");
		else
			TP_Printf("[mutex1 ok]\r\n");
		ry_task_delay(2000);
		if(ry_sem_release(&ipc_mutex) != RY_OK)
			TP_Printf("\r\nipc_mutex�����쳣\r\n");
	}
}
static void task_mutex_rec_exe(void *p)
{
	while(1)
	{
		if(ry_sem_rec(&ipc_mutex, -1) != RY_OK)
			TP_Printf("\r\nipc_mutex�����쳣\r\n");
		else
			TP_Printf("[mutex2 ok]\r\n");
		ry_task_delay(1000);
		if(ry_sem_release(&ipc_mutex) != RY_OK)
			TP_Printf("\r\nipc_mutex�����쳣\r\n");
	}
}
static void task_event_send_exe(void *p)
{
	while(1)
	{
		ry_event_send(&ipc_event, 0x05);
		ry_task_delay(1000);
		ry_event_send(&ipc_event, 0xA0);
		ry_task_delay(1000);
	}
}
static void task_event_rec_exe(void *p)
{
	uint8_t flag;
	while(1)
	{
		flag = ry_event_rec(&ipc_event, RY_ENENT_AND_RC, 0xA5, -1);
		TP_Printf("[event=%#X]", flag);
	}
}

static void timer_exe(void *p)
{
	TP_Printf("\r\n[cycle=10s]\r\n");
}

static void timer_cnt_exe(void *p)
{
	static uint32_t cnt = 0;
	TP_Printf("\r\n[timer_cnt=%d][cycle=5s]\r\n", cnt++);
}

static void task_breathe_led_exe(void *p)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOE, ENABLE);
	GPIO_InitStructure.GPIO_Pin   = GPIO_Pin_5;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	GPIO_Init(GPIOE, &GPIO_InitStructure);
	
	while(1)
	{
		GPIOE->BRR  = GPIO_Pin_5;
		GPIOB->BSRR = GPIO_Pin_5;
		ry_task_delay(50);
		GPIOB->BRR  = GPIO_Pin_5;
		GPIOE->BSRR = GPIO_Pin_5;
		ry_task_delay(260);
		
		GPIOE->BRR  = GPIO_Pin_5;
		GPIOB->BSRR = GPIO_Pin_5;
		ry_task_delay(50);
		GPIOB->BRR  = GPIO_Pin_5;
		GPIOE->BSRR = GPIO_Pin_5;
		ry_task_delay(50);
		
		GPIOE->BRR  = GPIO_Pin_5;
		GPIOB->BSRR = GPIO_Pin_5;
		ry_task_delay(50);
		GPIOB->BRR  = GPIO_Pin_5;
		GPIOE->BSRR = GPIO_Pin_5;
		ry_task_delay(50);
		
		GPIOE->BRR  = GPIO_Pin_5;
		GPIOB->BSRR = GPIO_Pin_5;
		ry_task_delay(50);
		GPIOB->BRR  = GPIO_Pin_5;
		GPIOE->BSRR = GPIO_Pin_5;
		ry_task_delay(50);
		
		GPIOE->BRR  = GPIO_Pin_5;
		GPIOB->BSRR = GPIO_Pin_5;
		ry_task_delay(50);
		GPIOB->BRR  = GPIO_Pin_5;
		GPIOE->BSRR = GPIO_Pin_5;
		ry_task_delay(260);
	}
}









