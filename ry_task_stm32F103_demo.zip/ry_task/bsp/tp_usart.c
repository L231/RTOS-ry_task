
#include <stdarg.h>
#include <string.h>

#include "tp_usart.h"
#include "tp_run.h"
#include "ry_lib.h"







void TP_USARTx_Init(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef  NVIC_InitStructure;

  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
	
	USARTx_CLK_CMD();
	TX_GPIO_CLK_CMD();
	RX_GPIO_CLK_CMD();
	
  NVIC_InitStructure.NVIC_IRQChannel                   = USARTx_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority        = 1;
  NVIC_InitStructure.NVIC_IRQChannelCmd                = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin   = TX_PIN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
	GPIO_Init(TX_GPIO, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin  = RX_PIN;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
	GPIO_Init(RX_GPIO, &GPIO_InitStructure);
	
	USART_InitStructure.USART_BaudRate            = 115200;
	USART_InitStructure.USART_WordLength          = USART_WordLength_8b;
	USART_InitStructure.USART_StopBits            = USART_StopBits_1;
	USART_InitStructure.USART_Parity              = USART_Parity_No;
	USART_InitStructure.USART_Mode                = USART_Mode_Tx | USART_Mode_Rx;
	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	USART_Init(USARTx, &USART_InitStructure);
	USART_ITConfig(USARTx, USART_IT_RXNE, ENABLE);
	USART_Cmd(USARTx, ENABLE);	
}


void USART_SendChar(char c)
{
	while(USART_GetFlagStatus(USARTx, USART_FLAG_TXE) == RESET);
	USART_SendData(USARTx, c);
}

void TP_USARTx_SendBuf(char *buf)
{
	while(*buf != '\0')
	{
		USART_SendChar(*buf++);
	}
	while(USART_GetFlagStatus(USARTx, USART_FLAG_TC)==RESET);
}
void tp_usart_send(char *buf, uint8_t len)
{
	while(len--)
	{
		USART_SendChar(*buf++);
	}
	while(USART_GetFlagStatus(USARTx, USART_FLAG_TC)==RESET);
}

/* �ض��� printf ���� */
int fputc(int ch, FILE *f)
{
	while((USARTx->SR & USART_FLAG_TXE) == RESET);
	USARTx->DR = ch;
	return ch;
}


void ry_printf(const char * fmt, ...)
{
	uint8_t len;
	va_list ap;
	static char buf[128];
	
	va_start(ap, fmt);
	len = vsprintf(buf, fmt, ap);
	va_end(ap);
	tp_usart_send(buf, len);
}


void USARTx_IRQHandler(void)
{
	char data;
	static uint8_t sRecCnt = 0;
	if(USART_GetITStatus(USARTx, USART_IT_RXNE) == SET)
	{
		data = USART_ReceiveData(USARTx);
		if(sRecCnt >= COMM_DATA_SIZE)
			sRecCnt = 0;
		gToMaster.RecBuf[sRecCnt++]   = data;
		
		USART_SendChar(data);  //����
		if(data == '\r' || data == '\n')
		{
//			USART_SendChar('\n');
			gToMaster.RecBuf[--sRecCnt] = '\0';
			gToMaster.RecComplete       = SET;
			sRecCnt                     = 0;
		}
	}
}

