#ifndef __TP_RUN_H__
	#define	__TP_RUN_H__

#include "stm32f10x.h"
#include "stdio.h"


#define  COMM_USART1
//#define  COMM_USART2
//#define  COMM_USART3


/***************************************** tp_run.c �ӿ�˵�� start ***********************************/

typedef void (*fun)(void);

typedef struct
{
	char  *Name;
	fun    func;
}MultipleTestItem;


#define  COMM_DATA_SIZE     (64)
typedef struct
{
	char                 RecBuf[COMM_DATA_SIZE];
	__IO FlagStatus      RecComplete;
}COMM_RecTypedef;

extern COMM_RecTypedef  gToMaster;


extern void TP_DriveInit(void);
extern void TP_SysRun(MultipleTestItem *p_stk);



/***************************************** tp_tools.c �ӿ�˵�� start ***********************************/

/* ��ʱ���� */
#define  _soft_delay(time)          do{\
                                        int32_t val = time;\
                                        while(val--)\
                                        {\
                                          __ASM("NOP");\
                                        }\
                                      }while(0)

extern void Delay_ms(uint16_t ms);
extern void Delay_us(uint16_t us);
																			

extern void TP_HSE_SetSysClock(uint32_t pllmul);


/**
 * �������������ͨ�ŵ��������
 **/
extern void TP_ClearCommData(void);


extern void TP_USARTx_Init(void);
//extern void TP_USARTx_SendBuf(char *buf);
																			
/**
 * ��������ʽ����ӡ����
 **/
#define  TP_Printf        printf
//extern void TP_Printf(const char *fmt, ...);


#endif
