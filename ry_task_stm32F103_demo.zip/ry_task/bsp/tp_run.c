
#include <string.h>

#include "tp_run.h"
#include "tp_usart.h"
#include "tp_tools.h"

#include "ry_conf.h"


/* ͨ�Žṹ�� */
COMM_RecTypedef  gToMaster;

/* ָ��ǰ������ */
MultipleTestItem *gCurrentItem;


void ry_systick_cfg(void)
{
	RCC_ClocksTypeDef  mcu_clk;
	RCC_GetClocksFreq(&mcu_clk);
	SysTick_Config(mcu_clk.SYSCLK_Frequency / 1000000 * RY_TICK_PERIOD);
}



void TP_DriveInit(void)
{
	Delay_Init();
	TP_USARTx_Init();
}


void TP_SysRun(MultipleTestItem *p_stk)
{
	TP_Printf("\n\r\n\r...\r");	
	while(1)
	{
		TP_ClearCommData();
		TP_Printf("\n.\\cmd>");
		while(1)
		{
			if(gToMaster.RecComplete)
			{
				for(gCurrentItem = p_stk; gCurrentItem->Name != NULL; gCurrentItem++)
				{
					if(strcmp(gToMaster.RecBuf, gCurrentItem->Name) == 0)
						break;
				}
				if(gCurrentItem->Name != NULL)
				{
					if(gCurrentItem->func == NULL)
						TP_Printf("NULL��\r\n");
					else
						gCurrentItem->func();
				}
				else
					TP_Printf("ERROR��\r\n");
				
				break;
			}
		}
	}	
}












