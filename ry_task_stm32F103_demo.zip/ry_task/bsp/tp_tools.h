#ifndef __TP_TOOLS_H__
	#define	__TP_TOOLS_H__

#include "stm32f10x.h"



extern void Delay_Init(void);
extern void TP_TrigLevel_Init(void);






#endif
