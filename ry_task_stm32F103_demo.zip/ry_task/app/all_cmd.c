#include "all_cmd.h"
#include "tp_run.h"
#include "string.h"

#include "t_task.h"

MultipleTestItem gAllTestItem[] =
{
	
	{"task",        F_ry_task},
	
	
	
	{NULL,   NULL},
};


