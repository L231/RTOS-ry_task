#ifndef __ALL_CMD_H__
#define	__ALL_CMD_H__

#include "tp_run.h"



extern MultipleTestItem gAllTestItem[];




#endif
