#ifndef __SDCARD_TEST_H__
	#define	__SDCARD_TEST_H__


#include "stm32f10x.h"



#define  FILE_PATH_LEN         (30)
#define  FILE_FN_LEN           (20)

typedef struct
{
	uint16_t  count;
	char      path[FILE_PATH_LEN];
	char      fn[FILE_FN_LEN];
}FileInfo;






extern void SDcard_MountFatFs(void);
extern void SDcard_GetDiskInfo(void);
extern void SDcard_ScanFile(char *path);


#endif
